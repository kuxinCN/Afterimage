/* 余像 Afterimage · 演示页脚本（不属于组件本体）
 * 负责把控制面板接到 MemorySpace 的公开接口上，并展示回调事件。
 */
(function () {
  'use strict';

  var mock = window.AfterimageMock;
  var currentDatasetKey = 'standard';

  var logEl = document.getElementById('event-log');
  var progressEl = document.getElementById('scene-progress');

  function pad(n) { return n < 10 ? '0' + n : '' + n; }

  function log(text, type) {
    var li = document.createElement('li');
    li.className = 'ev-' + (type || 'sys');
    var time = document.createElement('time');
    var now = new Date();
    time.textContent = pad(now.getHours()) + ':' + pad(now.getMinutes()) + ':' + pad(now.getSeconds());
    var span = document.createElement('span');
    span.textContent = text;
    li.appendChild(time);
    li.appendChild(span);
    logEl.insertBefore(li, logEl.firstChild);
    while (logEl.children.length > 40) logEl.removeChild(logEl.lastChild);
  }

  function updateProgress(state) {
    var viewed = state.fragments.filter(function (f) { return f.status === 'viewed'; }).length;
    progressEl.textContent = '已查看 ' + viewed + ' / ' + state.fragments.length + ' 枚碎片';
  }

  var systemReduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  var space = new window.Afterimage.MemorySpace(document.getElementById('scene'), {
    fragments: mock.standard,
    theme: 'dusk',
    layout: 'scatter',
    dust: 22,
    reduceMotion: systemReduce,
    onFragmentOpen: function (data, info) {
      log('onFragmentOpen → ' + data.title + '（此前：' + info.previousStatus + '）', 'open');
    },
    onFragmentClose: function (data, info) {
      log('onFragmentClose → ' + data.title + '（viewed' + (info && info.removed ? '，该 id 已被新数据移除' : '') + '）', 'close');
    },
    onStateChange: updateProgress
  });

  log('演示初始化：加载虚构模拟数据「没说出口的再见」，共 5 枚碎片', 'sys');
  if (systemReduce) log('检测到系统「减少动态效果」，动画已默认关闭', 'sys');

  /* ---------- CSS 变量类控件 ---------- */

  function bindRange(id, outId, cssVar, scale, fmt) {
    var input = document.getElementById(id);
    var out = document.getElementById(outId);
    function apply() {
      var v = Number(input.value);
      space.root.style.setProperty(cssVar, String(v / scale));
      out.textContent = fmt(v);
    }
    input.addEventListener('input', apply);
    apply();
    return input;
  }

  var pct = function (v) { return v + '%'; };
  var ctlAmbient = bindRange('ctl-ambient', 'out-ambient', '--ms-ambient', 100, pct);
  var ctlGlow = bindRange('ctl-glow', 'out-glow', '--ms-glow', 100, pct);
  var ctlFloat = bindRange('ctl-float', 'out-float', '--ms-float', 100, pct);
  var ctlScale = bindRange('ctl-scale', 'out-scale', '--ms-scale', 100, pct);

  var ctlDust = document.getElementById('ctl-dust');
  var outDust = document.getElementById('out-dust');
  ctlDust.addEventListener('input', function () {
    outDust.textContent = ctlDust.value;
    space.update({ dust: Number(ctlDust.value) });
  });

  /* ---------- 选择类控件 ---------- */

  var ctlTheme = document.getElementById('ctl-theme');
  ctlTheme.addEventListener('change', function () {
    space.update({ theme: ctlTheme.value });
    log('切换主题 → ' + ctlTheme.options[ctlTheme.selectedIndex].text, 'sys');
  });

  var ctlLayout = document.getElementById('ctl-layout');
  ctlLayout.addEventListener('change', function () {
    space.update({ layout: ctlLayout.value });
    log('切换布局 → ' + ctlLayout.options[ctlLayout.selectedIndex].text, 'sys');
  });

  var ctlDataset = document.getElementById('ctl-dataset');
  ctlDataset.addEventListener('change', function () {
    currentDatasetKey = ctlDataset.value;
    var report = space.setFragments(mock[currentDatasetKey], { preserveStatus: false });
    log('切换数据集 → ' + ctlDataset.options[ctlDataset.selectedIndex].text +
      '（保留 ' + report.kept + ' 枚）', 'sys');
    if (report.droppedDuplicateIds.length) {
      log('setFragments 去重：忽略重复 id ' + report.droppedDuplicateIds.join(', ') + '（保留首次出现）', 'sys');
    }
    if (report.closedOpenId) {
      log('更新时收起打开的碎片 ' + report.closedOpenId +
        (report.removedOpenId ? '（该 id 被移除）' : '（id 保留，状态 viewed）'), 'sys');
    }
  });

  var ctlMotion = document.getElementById('ctl-motion');
  var motionText = document.getElementById('motion-text');
  ctlMotion.checked = !systemReduce;
  motionText.textContent = ctlMotion.checked ? '开' : '关';
  ctlMotion.addEventListener('change', function () {
    space.update({ reduceMotion: !ctlMotion.checked });
    motionText.textContent = ctlMotion.checked ? '开' : '关';
    log('场景动画 → ' + (ctlMotion.checked ? '开' : '关'), 'sys');
  });

  /* ---------- 动作按钮 ---------- */

  document.getElementById('btn-reset').addEventListener('click', function () {
    space.reset();
    ctlAmbient.value = 100; ctlGlow.value = 100; ctlFloat.value = 100; ctlScale.value = 100;
    ctlDust.value = 22; outDust.textContent = '22';
    [ctlAmbient, ctlGlow, ctlFloat, ctlScale].forEach(function (input) {
      input.dispatchEvent(new Event('input'));
    });
    space.update({ dust: 22, theme: 'dusk', layout: 'scatter', reduceMotion: systemReduce });
    ctlTheme.value = 'dusk'; ctlLayout.value = 'scatter';
    ctlMotion.checked = !systemReduce;
    motionText.textContent = ctlMotion.checked ? '开' : '关';
    log('重置：所有碎片回到未查看，控件恢复默认', 'sys');
  });

  document.getElementById('btn-random').addEventListener('click', function () {
    var source = mock[currentDatasetKey];
    if (!source.length) {
      log('当前数据集为空，无法随机布局', 'sys');
      return;
    }
    if (ctlLayout.value !== 'scatter') {
      ctlLayout.value = 'scatter';
      space.update({ layout: 'scatter' });
    }

    // 以实测像素尺寸做成对防重叠放置，避免大缩放/窄屏下碎片互相遮挡
    var sceneRect = space.root.getBoundingClientRect();
    var W = sceneRect.width, H = sceneRect.height;
    var gap = 8;
    var sizes = space.fragments.map(function (f) {
      var r = f.el.getBoundingClientRect();
      return { hw: r.width / 2, hh: r.height / 2 };
    });

    var placed = [];
    var randomized = source.map(function (item, i) {
      var s = sizes[i] || { hw: 50, hh: 70 };
      // 组件会把坐标夹在 x[6,94]% y[10,86]%，放置边界需与之相交
      var minX = Math.max(0.06 * W, s.hw + gap);
      var maxX = Math.min(0.94 * W, W - s.hw - gap);
      var minY = Math.max(0.10 * H, s.hh + gap);
      var maxY = Math.min(0.86 * H, H - s.hh - gap);
      if (maxX < minX) { minX = maxX = W / 2; }
      if (maxY < minY) { minY = maxY = H / 2; }

      var x, y, ok, tries = 0;
      do {
        x = minX + Math.random() * (maxX - minX);
        y = minY + Math.random() * (maxY - minY);
        ok = placed.every(function (p) {
          return Math.abs(p.x - x) > p.hw + s.hw + gap ||
                 Math.abs(p.y - y) > p.hh + s.hh + gap;
        });
        tries++;
      } while (!ok && tries < 120);
      placed.push({ x: x, y: y, hw: s.hw, hh: s.hh });

      var copy = {};
      for (var k in item) copy[k] = item[k];
      copy.position = { x: Math.round(x / W * 100), y: Math.round(y / H * 100) };
      return copy;
    });

    space.setFragments(randomized, { preserveStatus: true });
    log('随机布局：重新散布 ' + randomized.length + ' 枚碎片（保留查看状态）', 'sys');
  });

  document.getElementById('btn-export').addEventListener('click', function () {
    var state = space.getState();
    var payload = {
      demo: '余像 Afterimage · 组件演示导出（模拟数据 / 虚构示例）',
      exportedAt: new Date().toISOString(),
      state: state
    };
    var blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'afterimage-memory-state.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    log('导出状态 JSON：' + state.fragments.length + ' 枚碎片', 'sys');
  });
})();