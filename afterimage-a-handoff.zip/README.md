# 余像 Afterimage · 任务 A：记忆场景与碎片组件

2D「记忆房间」场景组件 `MemorySpace` 与记忆碎片组件 `MemoryFragment` 的**独立演示**。
零第三方依赖、无构建步骤，原生 HTML/CSS/JavaScript。

> **模拟数据 / 虚构示例**：本演示未接入真实 AI。所有故事内容均为虚构，
> 不代表真实记忆，也不是真实的人生预测。正式产品中 AI 生成的平行情节同样属于虚构内容。

## 如何运行

直接用浏览器打开 `index.html` 即可（`file://` 协议可运行，脚本未使用 ES Module，无跨域限制）。
也可以起任意静态服务器，例如：

```bash
npx serve .        # 或 python -m http.server
```

对接演示（外部 scene / 外部探索状态 / 来源标签 / 保存失败不乐观标记）：打开 `integration-demo.html`。
该演示使用 A 自编虚构 C 形状数据，**模拟数据 / 未接入真实 AI / 未与 C 组实际联调**。

## 文件结构

```
index.html                  独立演示入口（含控制面板、事件日志）
integration-demo.html       对接演示入口（外部 scene / 外部探索 / 来源标签）
src/memory-fragment.js      MemoryFragment 组件（单碎片展示与交互 + 外部 explored 徽标）
src/memory-space.js         MemorySpace 组件（场景、详情面板、三态 + 外部 explored、回调分离）
src/scene-adapter.js        SceneAdapter 适配层（外部 scene/hotspot → A fragments，纯转换）
src/scene-mount.js          mountScene 客户端挂载接口（一站式接外部数据/回调）
integrations/react/AfterimageMemoryScene.jsx   React/Next 包装组件（未运行时验证）
styles/memory-fragment.css  碎片样式
styles/memory-space.css     场景样式（含三套主题与 CSS 变量）
styles/demo.css             演示页外壳样式（不属于组件）
data/mock-fragments.js      虚构模拟数据（标准 / 边界用例 / 空列表）
data/mock-scene.js          对接演示用虚构 C 形状 scene 数据（A 自编）
demo/demo.js                独立演示接线脚本（不属于组件）
demo/integration-demo.js    对接演示接线脚本（不属于组件）
docs/c-team-integration-reference.md   A↔C 差异分析（仅代码阅读）
docs/a-handoff-for-c.md     面向 C 的交付接入说明
checks/self-check.html      零依赖浏览器自检入口（32 项断言）
checks/self-check.js        自检断言脚本
```

迁移到团队项目时，搬走 `src/` 四个脚本 + `styles/` 两个组件 css（React 接入再加
`integrations/react/`）；`data/`、`demo/`、`styles/demo.css`、两个 html 可整体丢弃或替换。

## 数据格式（B / C 的数据入口）

组件不内置任何故事。数据通过构造参数或 `setFragments()` 传入：

```js
{
  id: 'photo-01',          // 必填建议：稳定唯一 id（缺省时按序号生成）
  kind: 'photo',           // photo | note | ticket | clock | cup，未知值回退为 keepsake
  title: '站台合影',        // 缺省回退「未命名碎片」；过长时标签截断、面板完整换行
  content: '详情正文…',     // 支持 \n 分段；为空时显示占位文案；很长时面板内滚动
  position: { x: 16, y: 32 } // 可选，场景内百分比坐标；缺省自动分配安全位置
}
```

其余字段会原样保留在回调的 `data.raw` 中，方便 B 附带故事节点 id 等业务字段。

## MemorySpace API

```js
const space = new Afterimage.MemorySpace(containerEl, {
  fragments: [...],        // 上述数据数组；空数组显示空态提示
  theme: 'dusk',           // dusk | amber | moss
  layout: 'scatter',       // scatter 散落 | shelf 陈列架
  dust: 22,                // 尘埃粒子数 0–80
  reduceMotion: false,     // 缺省跟随系统 prefers-reduced-motion
  onFragmentOpen(data, info) {},   // info: { id, previousStatus }
  onFragmentClose(data, info) {},  // info: { id, status: 'viewed', removed? }
  onStateChange(state) {},         // 任何状态变化后触发
  exploredIds: ['hs-xx'],          // 外部已探索 id（持久化结果的来源；A 不写存储）
  exploreOn: 'open',               // 'open'|'close'|'none'：用户何时上报探索请求
  onExploreRequest(id, info) {}    // 仅「用户」触发且 exploreOn 匹配时发出；info:{trigger}
});

space.setFragments(list, { preserveStatus: true, preserveExplored: true, preserveOpen: false }); // 换数据；默认保留同 id 的 viewed/explored；preserveOpen=true 时仍存在的打开项保持阅读；返回更新报告
space.setExplored(ids);        // 仅回灌外部探索态；不触发用户回调、不改内部 viewed
space.openFragment(id);        // 编程式打开（不视为用户点击）
space.closePanel();            // 编程式收起（标记 viewed，不视为用户点击）
space.reset();                 // 全部回到 unseen
space.update({ theme, layout, dust, reduceMotion, exploreOn }); // 局部更新
space.getState();              // { theme, layout, reduceMotion, exploreOn, openId, exploredIds, fragments:[{id,kind,title,status,explored}] }
space.destroy();               // 移除 DOM 与监听器
```

`MemoryFragment` 一般由 `MemorySpace` 内部创建；也可单独使用：
`new Afterimage.MemoryFragment({ data, status, onActivate })`，暴露
`el / setStatus() / setPosition() / update() / destroy()`。

## 状态与交互约定

- **三轴互不覆盖**：内部阅读三态 `unseen → open → viewed`（viewed 在**关闭**详情时标记，内存态）；
  外部探索 `explored`（**仅**由外部经 `setExplored`/`exploredIds` 回灌，A 不做乐观标记、不写 C 存储）；
  用户点击上报 `onExploreRequest`（仅用户触发且 `exploreOn` 匹配）。
  收起面板即标记 viewed；切换到另一碎片时，前一枚自动标记 viewed 并触发 `onFragmentClose`。
- 外部记录失败时不回灌 → 界面不显示已探索；A 不宣称未确认保存的状态为已持久化。
- 程序调用（`openFragment`/`closePanel`/`setFragments`/`setExplored`/`update`）**不**触发 `onExploreRequest`。
- 状态徽标始终为「图标 + 文字」，不只依赖颜色。
- 碎片是原生 `<button>`：鼠标、触屏、Tab + 回车/空格均可操作；
  Esc 收起面板；打开时焦点移入面板，收起后归还碎片按钮；`aria-live` 播报状态。
- 无自动声音、无自动视频；动画遵循系统「减少动态效果」设置。

## setFragments() 数据更新与状态对接（C 必读）

C 可能在详情打开时调用 `setFragments()` 推送新故事数据。其行为约定如下（确定性、可预期）：

1. **打开中的碎片如何关闭**：更新会先把当前打开的详情按「一次正常关闭」处理——隐藏面板、
   将该碎片标记为 `viewed`、清空 `openId`，并通过 `aria-live` 播报「数据更新：已收起 …」。
   不会把面板留在打开状态指向旧数据。
2. **是否触发 onFragmentClose**：会。上述更新导致的关闭与用户手动关闭走同一语义，
   触发 `onFragmentClose(data, info)`，`info = { id, status: 'viewed', removed }`。
   `removed: true` 表示该 id 已不在新数据中（见第 4 点）。这是相对早期版本的行为变化：
   早期更新时静默关闭、不触发回调；现在统一触发，便于 C 记录阅读进度。
3. **已查看状态保留**：`preserveStatus !== false`（默认）时，旧数据中为 `viewed` 且
   **同 id 仍存在于新数据**的碎片保留 `viewed`；新出现的 id 为 `unseen`。
   第 1 点中刚被关闭的碎片同样记为 `viewed`，若其 id 保留则延续。
   **任何被移除的 id 都不保留状态**——无论是普通已查看碎片还是刚关闭那枚：
   其 viewed 不会残留在内部状态表里，该 id 之后重新出现时一律作为 `unseen`。
   `preserveStatus: false` 表示显式重置：全部回到 `unseen`（含刚关闭的那枚）。
4. **打开的碎片被移除**：面板同样关闭并触发 `onFragmentClose`，但 `info.removed = true`；
   该 id 的状态不再保留（新数据中已无此碎片）。焦点不会滞留在已隐藏的面板里：
   若原焦点在面板/旧碎片按钮上且该 id 仍存在，重建后焦点落到对应新按钮；否则交还页面。
5. **重复 id**：不静默。同一 id **保留首次出现**、忽略后续重复项；被忽略的 id 通过
   `console.warn` 提示，并计入返回报告。因此不会出现同 id 的多个按钮或状态互相覆盖。
   建议 C/B 始终提供稳定唯一 id；缺省 id 时按「原始序号」生成回退 id（`fragment-<index>`），
   重排无 id 数据不会延续状态。

**返回报告**（新增，向后兼容——旧调用忽略返回值即可）：

```js
const report = space.setFragments(list, opts);
// {
//   kept: 3,                    // 去重后实际渲染的碎片数
//   droppedDuplicateIds: ['dup-01', 'dup-02'], // 被忽略的重复 id
//   closedOpenId: 'photo-01',   // 更新前处于打开状态、本次被关闭的 id（无则 null）
//   removedOpenId: 'photo-01',  // 上述 id 若被新数据移除则等于它，否则 null
//   preservedOpenId: 'photo-01' // preserveOpen=true 且该 id 仍存在、详情保持打开时等于它，否则 null
// }
```

**preserveOpen（新增，默认 false 保持旧行为）**：`preserveOpen: true` 时，若更新前打开的碎片 id
**仍存在于新数据**，则不关闭面板、不触发 `onFragmentClose`，而是把面板内容同步到新数据并保持打开
（`preservedOpenId` 返回该 id）；焦点若已在面板内则保持不动。若该 id 被移除，仍按第 1/4 点安全关闭并报告。
`mountScene.update()` 在 scene 真变化时默认采用 `preserveOpen: true`；**仅 visitedHotspots 变化时根本不调用
`setFragments`**，只回灌探索态，因此不会打断阅读、不重建碎片、不丢焦点。

**其它关闭路径的回调语义**（保持一致）：用户点「收起」/ Esc / 再次点击同碎片 / 切换到另一碎片，
均触发 `onFragmentClose` 并标记 viewed。`reset()` 是批量重置、**不**触发 `onFragmentClose`。

## 数据适配与客户端挂载（C 对接）

外部（C 形状）scene/hotspot 经适配层转换后交给组件，详见 `docs/a-handoff-for-c.md`：

```js
// 纯转换：不读库、不联网、不生成故事；降级/跳过经 issues 显式返回
const { fragments, meta, issues, exploredIds } =
  Afterimage.SceneAdapter.adaptScene(scene, { visitedHotspots, kindMap, defaultKind });

// 客户端一站式挂载（需 document）；卸载 destroy 清理节点与监听
const handle = Afterimage.mountScene(el, {
  scene, visitedHotspots,
  onHotspotClick: id => {/* 外部在此记录探索，成功后回灌 */},
  exploreOn: 'open'
});
handle.update({ scene, visitedHotspots });  // 程序更新，不伪装用户点击；仅 visited 变化只回灌不重建，scene 真变化保留仍存在的打开项
handle.setVisited(ids); handle.destroy();
```

规则要点：沿用外部 `hotspot.id`；0~1 坐标×100；缺 id 跳过、重复 id 保留首条、异常坐标夹取、
超长名称截断，均记 issue；`type` 不等同视觉 `kind`（仅显式 kindMap 映射，否则通用图形）；
保留 sourceType/sourceIds/confidence/confirmed，且 confirmed 仅 user_confirmed 可为 true。

React/Next：`integrations/react/AfterimageMemoryScene.jsx`（props 与 C `SceneCanvas` 契约对齐：
`scene / visitedHotspots / onHotspotClick`）。**该包装组件未经 React/Next 运行时验证**；
A 核心为客户端脚本，包装组件经 useEffect + dynamic import 限定客户端加载以避开 SSR。

## 样式调节（CSS 变量，挂在场景根元素 `.ms` 上）

| 变量 | 含义 | 默认 |
| --- | --- | --- |
| `--ms-ambient` | 环境光亮度 | 1 |
| `--ms-glow` | 光晕强度 | 1 |
| `--ms-float` | 碎片浮动幅度 | 1 |
| `--ms-scale` | 碎片整体缩放 | 1 |

主题色全部来自 `.ms--theme-*` 的自定义属性，C 可按项目设计系统覆盖。

## 给 C 的集成建议

- 完整接入说明、字段映射、事件差异、需 C 自行完成的操作见 **`docs/a-handoff-for-c.md`**；
  差异分析见 `docs/c-team-integration-reference.md`。两者均为 A 单方面建议，**未与 C 协商确认**。
- 推荐在 C 的 `MemoryScenePanel` 内以 A 包装组件替换/并列 `SceneCanvas`（props 契约一致）；
  该替换属 C 侧改动，由 C 决定并实施，A 不改 C 文件。
- 组件是命令式类（无框架依赖）；不用 React 时可直接 `mountScene` + `useEffect`/`onMounted` 挂载、卸载 `destroy()`。
- 当前为独立演示 + 对接演示，**未**集成进 C 项目，未实现后端、真实 AI、登录、上传或部署。

## 已知边界与待协调

- 碎片图形为内置 SVG（照片/纸条/车票/钟表/杯子/通用纪念物），新增类型需在
  `memory-fragment.js` 的 `VISUALS` 与 `KIND_LABELS` 中登记。
- scatter 布局仅 8 个槽位（取模复用），**>8 枚碎片会重叠**；C 热点上限 24，对接大量热点前需 A 增强布局（待验证）。
- A 无逐碎片深度/缩放（C 有 depthBand）；视觉深度差异需 A 增强或接受差异（待 C 确认）。
- 详情面板为非模态对话框（`aria-modal="false"`），焦点可 Tab 出面板；若 C 需要模态遮罩可在外层包装。
- React 包装组件未经运行时验证；C 接入时需自行验证 SSR/卸载/Tailwind 共存。