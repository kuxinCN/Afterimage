# 余像 Afterimage · A 组交付接入说明（面向 C 组）

> **性质声明**：本文为 A 组单方面的**接入建议与交付说明**，所有"建议 / 推荐 / 约定方向"**均未与 C 组协商确认**，不构成双方已同意的最终接口约定。
> **未接入真实 AI、未修改 C 组任何代码、未与 C 组做实际联调。** 标注"未验证"的内容请勿当作已验证事实。
> 前置分析见 `docs/c-team-integration-reference.md`（仅代码阅读的差异分析）。

## 1. A 组交付文件清单

组件与适配层（C 接入所需）：
- `src/memory-fragment.js` — 单碎片组件（含外部 explored 徽标）
- `src/memory-space.js` — 场景组件（三态 + 外部 explored + 用户/程序回调分离）
- `src/scene-adapter.js` — 外部 scene/hotspot → A fragments 的纯转换适配层
- `src/scene-mount.js` — 客户端一站式挂载接口 `Afterimage.mountScene`
- `styles/memory-fragment.css`、`styles/memory-space.css` — 组件样式
- `integrations/react/AfterimageMemoryScene.jsx` — React/Next 包装组件（**未运行时验证**）

演示与数据（可丢弃/替换，不属于组件）：
- `index.html` + `demo/demo.js` + `data/mock-fragments.js` + `styles/demo.css` — 原独立演示（保留）
- `integration-demo.html` + `demo/integration-demo.js` + `data/mock-scene.js` — 对接演示（A 自编虚构 C 形状数据）

文档与约定：
- `README.md`、`AGENTS.md`、`docs/c-team-integration-reference.md`、`docs/a-handoff-for-c.md`

检查：`checks/self-check.html` + `checks/self-check.js`（零依赖浏览器自检，39 项断言，实测 39/39 通过）；
无自动化测试框架（A 为零依赖项目，未引入 vitest 等）。浏览器实测记录见 §8。

## 2. 输入 / 输出与最小使用示例

### 2.1 适配层（纯函数，无 DOM/网络/存储）

```js
const { fragments, meta, issues, exploredIds } =
  Afterimage.SceneAdapter.adaptScene(externalScene, {
    visitedHotspots: externalVisited,   // 外部已探索 id 列表
    kindMap: { object: 'keepsake' },    // 可选：C type → A kind 显式映射
    defaultKind: 'keepsake',            // 无映射时的通用图形
    maxNameLength: 120
  });
// issues: [{ code, message, hotspotId }] 显式降级/跳过报告，不静默
```

单热点：`adaptHotspot(hotspot, opts) → { fragment, issues }`（fragment 为 null 表示跳过）。
孤儿过滤：`pickExploredIds(visited, fragmentsOrIds) → string[]`（丢弃不在当前碎片中的 id）。

### 2.2 客户端挂载接口（任意框架可用，需 document）

```js
const handle = Afterimage.mountScene(containerEl, {
  scene: externalScene,
  visitedHotspots: externalVisited,
  onHotspotClick: (id) => { /* = C 的 onHotspotClick；在此调 C visitHotspot */ },
  exploreOn: 'open',                 // 'open'|'close'|'none'
  onIssues: (issues) => {},
  theme: 'dusk', layout: 'scatter'
});
handle.update({ scene: newScene, visitedHotspots: newVisited }); // 程序更新，不伪装用户点击
//   · 仅 visitedHotspots 变化（scene 内容未变）→ 只回灌探索态：不重建碎片、不打断详情、不丢焦点
//   · scene 真变化 → setFragments(preserveOpen:true)：仍存在的打开项保持阅读；被移除才安全关闭+报告
//   · 返回报告含 sceneChanged / preservedOpenId / closedOpenId / removedOpenId
handle.setVisited(ids);            // 仅回灌外部探索态（React 包装在 visited 变化时走此路径）
handle.getState();                 // { ...spaceState, meta, issues }
handle.destroy();                  // 移除 A 创建的节点与监听
```

### 2.3 React / Next（未运行时验证）

```jsx
"use client";
import AfterimageMemoryScene from "@/components/afterimage/AfterimageMemoryScene";
// 需同时引入 A 的两个 css（全局或模块级）
<AfterimageMemoryScene
  scene={scene}
  visitedHotspots={visitedHotspots}
  onHotspotClick={(id) => visitHotspot(memoryId, id)}
  exploreOn="open"
/>
```
包装组件内部用 `useEffect` + dynamic import 加载 A 核心（客户端 only），卸载时 `destroy()`。
若 C 将 A 文件放在别处，传 `loadCore` prop 自定义加载路径。

## 3. scene / hotspot 字段映射

| C 字段 | A 字段 | 规则 |
|---|---|---|
| `hotspot.id` | `fragment.id` | **直接沿用**，不重新生成 |
| `hotspot.name` | `fragment.title` | trim；空→「未命名碎片」+issue；>120 截断+issue |
| `hotspot.description` | `fragment.content` | 非字符串→''+issue；保留换行 |
| `hotspot.position{x,y}`(0~1) | `fragment.position{x,y}`(百分比) | ×100；超界夹取到[0,1]+issue；缺失→null+issue（组件自动布点） |
| `hotspot.type` | `fragment.kind` | **不等同**；仅 `kindMap` 显式映射才采用，否则 `defaultKind`(keepsake)+issue；不靠名称猜 |
| `hotspot.sourceType` | `fragment.sourceType` / `raw.sourceType` | 原样保留；缺失→null+issue（不编造） |
| `hotspot.sourceIds` | `fragment.sourceIds` / `raw.sourceIds` | 保留字符串数组；非数组→[]+issue |
| `hotspot.confidence` | `fragment.confidence` | 0~1 夹取；非法→null+issue |
| `hotspot.confirmed` | `fragment.confirmed` | **仅 sourceType==='user_confirmed' 才可为 true**；否则强制 false+issue（绝不升级） |
| `scene.{id,memoryId,template,title,version,background}` | `meta.*` | 透传，缺失→null |
| `exploration.visitedHotspots` | `exploredIds` / `fragment.explored` | 经 `pickExploredIds` 过滤孤儿后回灌 |

`fragment.raw` 保留原始热点业务字段，但来源字段经规范化（confirmed 不升级），供面板安全展示。

## 4. 坐标 / 唯一 ID / 重复 ID / 来源规则

- **坐标**：C 0~1 → A 百分比 ×100。A `setPosition` 另有夹取 x[6,94]、y[10,86]（组件层），极端值会被裁剪；如需放宽由 A 侧调整（待 C 确认需求）。
- **唯一 ID**：沿用 C `hotspot.id`（内容哈希 `hs-8hex`）。C 改名→id 变→旧探索孤儿；适配层 `pickExploredIds` 会丢弃孤儿，不写入。是否改 UUID 由 C 决策。
- **重复 ID**：适配层与 `setFragments` 均**保留首条、忽略后续**，记 `DUPLICATE_ID` issue / `console.warn` + 返回报告。C 的 Zod 在校验期即拒绝重复，故正常 C 数据不会触发。
- **缺 ID**：跳过该热点 + `MISSING_ID` issue，**不编造 id**。
- **来源**：四类 sourceType 保留；面板显示中文标签 + 对非 user_confirmed 标注「非用户确认」；推测/虚构绝不呈现为用户确认。

## 5. 外部探索态 vs A 内部阅读态（三轴，互不覆盖）

| 轴 | 含义 | 触发 | 持久化 |
|---|---|---|---|
| `status: open` | 当前打开详情 | 用户点击 / 程序 openFragment | 否 |
| `status: viewed` | 本次会话已查看 | **关闭**详情时（用户或程序关闭） | 否（内存） |
| `explored: true` | 外部已探索 | **仅**外部经 `setVisited`/`visitedHotspots` 回灌 | 由 C 持久化；A 不写 |

- A **不做乐观标记**：用户点击只发 `onHotspotClick` 请求；只有外部把 id 回灌，界面才显示已探索。外部记录失败→不回灌→不显示已探索（演示已验证）。
- A **不直接写 C 存储**、不调 C services/Repository。

## 6. 用户触发 vs 程序调用的事件差异

| 动作 | onFragmentOpen | onFragmentClose | onExploreRequest→onHotspotClick |
|---|---|---|---|
| 用户点击碎片打开 | ✔ | — | ✔（exploreOn='open'） |
| 用户收起/Esc/再点同碎片 | — | ✔ | ✔（exploreOn='close'） |
| 用户点击切换到另一碎片 | ✔(新) | ✔(旧,程序性自动关闭) | ✔(新,open)；旧不发 |
| 程序 `openFragment(id)` | ✔ | — | ✘ |
| 程序 `closePanel()` | — | ✔ | ✘ |
| 程序 `setFragments()` 默认（preserveOpen=false） | — | ✔(若有关闭) | ✘ |
| 程序 `setFragments(preserveOpen:true)` 且打开项仍存在 | —(面板内容刷新) | ✘ | ✘ |
| 程序 `setFragments(preserveOpen:true)` 且打开项被移除 | — | ✔(removed:true) | ✘ |
| `mountScene.update()` 仅 visitedHotspots 变化 | ✘ | ✘ | ✘（不重建碎片） |
| 程序 `setVisited()/update()` | ✘ | ✘ | ✘ |
| `reset()` | ✘ | ✘ | ✘ |

`exploreOn='none'` 时完全不发探索请求（仅保留 open/close 回调）。默认 `'open'` 与 C「点击即探索」对齐；**该对齐为建议，待 C 确认**。

## 7. C 组建议接入位置与需 C 自行完成的操作

- **建议位置**：`src/components/scene/MemoryScenePanel.jsx` 内，将 `SceneCanvas` 替换为或并列 A 包装组件（`SceneCanvas` props 契约 `{scene, visitedHotspots, onHotspotClick}` 与 A 包装一致）。**替换/并列属 C 侧改动，由 C 决定并实施；A 不改 C 文件。**
- **需 C 做**：
  1. 引入 A 的 `src/*` 四个脚本与两个 css（或经包装组件 dynamic import）。
  2. 在 `onHotspotClick(id)` 内调 C 现有 `visitHotspot(memoryId, id)`；成功后把最新 `visitedHotspots` 回灌（props 或 `setVisited`）。
  3. 保持 C 的生成门禁（status ready/completed）与状态管理不变；A 不绕过。
  4. 处理 Tailwind preflight 与 A CSS 共存、client-only 挂载（包装组件已处理 SSR）。
  5. 决策：热点 id 稳定性、坐标夹取放宽、24 热点防重叠（A 现仅 8 槽位，>8 会重叠，**需 A 侧增强或 C 限制数量**）、来源标签 UI 归属。
- **需 B/C 确认**：探索触发时机对齐、真实 AI 输出与 sceneSchema 对齐、background=asset 隐私边界、provenance 文案。

## 8. 实际验证结果（浏览器实测，file:// + 内置浏览器）

| 检查项 | 结果 |
|---|---|
| 旧独立演示未损坏（5 碎片、开/关/viewed、无控制台报错） | 通过 |
| 模拟热点字段/坐标转换（id/name/description/×100） | 通过 |
| ID/来源/外部探索在转换与更新中不丢失 | 通过 |
| 空场景/ null scene/缺 ID/重复 ID/异常坐标夹取/缺坐标/超长截断/非字符串描述/未知 type | 通过 |
| 用户点击产生 onHotspotClick；程序 open/close/update/setVisited 不伪装点击 | 通过 |
| 外部记录失败不标记已探索（无乐观标记） | 通过 |
| 开/关/数据更新状态回归（viewed 保留、移除 id 重置、打开项被移除回调+报告） | 通过 |
| 用户文字按文本呈现（`<img onerror>`/`<script>` 不执行、不注入节点） | 通过 |
| mountScene 挂载/卸载 DOM 清理 | 通过 |
| 交付自检 checks/self-check.html（39 项断言） | 通过（39/39） |
| 仅 visitedHotspots 更新：详情保持打开/探索徽标正确/不重复点击/不触发关闭/焦点在面板 | 通过 |
| scene 同内容新对象：不打断正在阅读的详情 | 通过 |
| scene 真变化且打开项仍存在：保持阅读（preserveOpen） | 通过 |
| scene 真变化且打开项被移除：安全关闭 + removed 报告 + onFragmentClose | 通过 |
| React 包装组件 / Next SSR 运行时 | **未验证**（A 工作区无 React/Next 环境，未安装依赖） |
| 与 C 组真实项目联调 | **未验证 / 未做** |

## 9. 已知限制与风险

- A 为客户端全局脚本（非 ESM）；模块顶层已改为 `window||globalThis` 以降低 SSR import 风险，但**挂载仍需客户端**。
- A scatter 仅 8 槽位，>8 碎片重叠；C 上限 24。对接大量热点前需 A 增强布局（待验证）。
- A 无逐碎片深度/缩放（C 有 depthBand）；视觉深度差异需 A 增强或接受差异（待 C 确认）。
- React 包装组件未经运行时测试；C 接入时需自行验证。其 visited 变化走 `setVisited`、scene 变化走 `update`，但同样未实测。
- `mountScene.update` 用 `JSON.stringify(scene)` 判断 scene 内容是否变化：键序不同会被判为"变化"，但此时 `preserveOpen` 仍会保留打开项，不会打断阅读；仅性能上多一次重建。
- 探索语义对齐（open vs close）、id 稳定性、来源 UI 归属均为**建议**，待 B/C 确认。

## 10. 重申

未接入真实 AI；未修改 C 组代码；未做实际联调；未部署；未推送 GitHub。C 参考包仅只读核对。