# 余像 Afterimage · A↔C 对接参考说明（初步 · 仅代码阅读）

> **状态声明**：本文全部结论来自对 A、C 双方**源代码的阅读**，未运行 C 项目、未安装依赖、未做 A↔C 联调。
> 所有"适配方向 / 建议"一律标注 **待验证**；凡未与 B、C 协商确认的接口或规则，均不写成已确定事实。
> C 组代码仅供读取分析，**未修改、未复制进 A 组交付内容**。

## 0. 参考资料来源与读取范围

- **A 组（本工作区 `D:\afterimage`）**：`README.md`、`src/memory-space.js`、`src/memory-fragment.js`、
  `data/mock-fragments.js`、`index.html`、`styles/memory-space.css`、`styles/memory-fragment.css`。
- **C 组参考包**：`D:\afterimage\Afterimage-0.1.0-tzw.zip`。因 Read 工具无法直读 zip，已解压到
  **系统临时目录（工作区之外）**：`C:\Users\ssn\AppData\Local\Temp\afterimage-c-ref.6dqCdn\Afterimage-0.1.0-tzw`。
  原压缩包未改动；解压副本不在 A 交付目录内。
- **实际读取的 C 文件**：`AGENTS.md`、`package.json`、`src/lib/constants.js`、
  `src/schemas/{sceneSchema,explorationSchema,sourceSchema,memorySchema,assetSchema}.js`、
  `src/components/scene/{SceneCanvas,MemoryScenePanel}.jsx`、`src/app/memory/[id]/page.js`、
  `src/services/scene/{sceneService,sceneTemplates}.js`、`src/services/storage/explorationRepository.js`、
  `src/services/ai/aiService.js`（`generateScene` 段）、`src/services/ai/providers/mockProvider.js`（`buildScene` 段）。
- C 其余文件（上传、分析面板、其余 repository、tests 等）本次未逐读；如后续对接涉及需补读。

## 1. 两组技术栈与负责范围

| | A 组（本工作区） | C 组（参考包） |
|---|---|---|
| 技术栈 | 原生 HTML/CSS/JS，零第三方依赖、无构建 | Next.js 14.2 + React 18 + App Router + JS + Tailwind 3.4 + IndexedDB(`idb`) + Zod + vitest |
| 组件形态 | 命令式类，全局命名空间 `window.Afterimage`，非 ES Module | React 函数组件（ESM/JSX，`@/` 别名），`"use client"` |
| 负责范围 | 2D 记忆场景视觉、碎片交互、三态、无障碍、独立演示 | 页面流程、状态管理、服务编排、IndexedDB 持久化、Zod 校验、AI 编排（当前 mock provider） |
| 数据 | 虚构模拟数据 `data/mock-fragments.js`，组件不内置故事 | 真实流程数据（memory/asset/scene/exploration），本地持久化 |

B 组负责真实 AI / 后端 / 故事数据；本次未读 B 代码。C 包内 `aiService`/`mockProvider` 属 C 侧编排与模拟，不等同于 B 的真实 AI。
C `AGENTS.md` 明确：未经批准不得改技术栈、UI 与业务分离、AI 走服务端、密钥不进浏览器、Repository 访问数据、Zod 校验外部数据、场景生成独立于 React。

## 2. 字段对照（基于实际代码）

| A `fragment` | C `hotspot` / `scene` | 说明 |
|---|---|---|
| `id`（调用方提供的稳定字符串） | `hotspot.id` | C 热点 id 为**内容哈希** `hs-<8hex>`（`sceneTemplates.assignHotspotIds`，FNV-1a(name)，重名加后缀）；scene/memory 的 id 由 repository stamped（C AGENTS 要求 UUID）。两者生成机制不同，见 §5 |
| `title` | `hotspot.name` | C `name` trim、1–120 字符 |
| `content` | `hotspot.description` | C ≤2000 字符、默认 `""`；A 为空时有占位文案 |
| `kind`（photo/note/ticket/clock/cup/keepsake） | `hotspot.type` | 语义不同：A `kind` 决定内置 SVG 图形；C `type` 为自由字符串 ≤40、默认 `"object"`（mock 恒为 object）。不能直接互译 |
| `position {x,y}`（**百分比 0–100**，夹取 x[6,94]、y[10,86]） | `hotspot.position {x,y}`（**归一化 0–1**，Zod strict） | 单位不同，需 ×100 转换，见 §3 |
| `status`（unseen/open/viewed，客户端内存） | `exploration.visitedHotspots[]`（IndexedDB 持久化，per memoryId） | C 无 "open/阅读中" 第三态；触发时机不同，见 §4 |
| （无） | `hotspot.sourceType` + `hotspot.sourceIds[]` | **A 缺失来源字段**，适配必须携带，见 §6 |
| （无） | `sourcedValue.confidence / confirmed`（analysis 层） | A 无对应；透传保留 |
| `raw`（保留原始输入字段） | — | A 的 `raw` 可作为携带 C 额外字段（sourceType/sourceIds/confidence/confirmed/scene 元信息）的通道 |
| （无） | `scene.{id,memoryId,template,title,background,version,createdAt,updatedAt}` | A 组件不感知 scene 级元信息；由适配层/C 持有 |

C `hotspotListSchema` 在**校验期拒绝重复 id**（整份 scene 报错）；A `setFragments` 对重复 id **保留首条、忽略后续**并 `console.warn` + 返回报告。两者容错策略不同，适配层应在送入 A 之前保证 id 唯一（C 已校验）。

## 3. 坐标单位 / 范围与转换（待验证）

- **单位**：C 归一化 0–1 → A 百分比 = `值 × 100`。反向 = `/100`。
- **夹取**：A `setPosition` 夹取 x[6,94]、y[10,86]（`memory-fragment.js:175-176`）。C 模板槽位
  x∈[0.06,0.94]、y∈[0.24,0.86]（`sceneTemplates.TEMPLATE_LAYOUTS`），换算后大致落在 A 夹取区间内但**边界相切**；
  极端值会被 A 裁剪。需确认：放宽 A 夹取，或由适配层预夹取（**待验证**，A 侧）。
- **深度**：C 有深度带 `depthBandFor(y)`：far(y<0.4)/mid(y≤0.7)/near(y>0.7) → scale 0.82/1/1.18、zIndex 10/20/30、opacity 0.72/0.9/1；visited 再 ×0.5（`sceneTemplates.hotspotLayout`）。
  A **无逐碎片深度/缩放/透明度**（`--ms-scale` 为全局变量）。适配方向：A 增加逐碎片 scale/z/opacity，或适配层映射（**待验证**，A 侧）。
- **数量与防重叠**：C `SCENE_LIMITS.MAX_HOTSPOTS = 24`，标记尺寸 `w-[3.4%]` 保证不重叠。
  A `SCATTER_SLOTS` 仅 **8 个槽位**且按 `index % 8` 复用（`memory-space.js:11-15,138`），**>8 枚碎片会位置重复→重叠**。
  对接 24 热点前 A 必须增强防重叠布局（**待验证**，A 侧工作）。

## 4. "已查看"(A) 与 "已探索"(C) 的语义差异

- **A `viewed`**：在详情面板**关闭**时标记（`closePanel` / 切换碎片 / `setFragments` 关闭打开项）；纯客户端内存，刷新即失（除非外部持久化）；含第三态 `open`。
- **C `visited`**：在热点**点击**时 `visitHotspot(memoryId, hotspotId)` → `ExplorationRepository.markHotspotVisited` 事务写 IndexedDB（去重、per memoryId）；**重新生成场景不丢失**（scene id 不变、version+1、热点 id 内容哈希稳定）；二态 visited/not。
- **触发时机不同（close vs click）**。适配方向：适配层在 A `onFragmentOpen`（用户点击打开）时回调 C `onHotspotClick(id)`→`visitHotspot`，使"探索"语义与 C 一致；A `viewed` 仅作 UI 呈现。此为方向，**需 B/C 确认（待验证）**。
- **孤儿 id**：C `visitHotspot` 校验热点存在于当前 scene，否则抛 `VALIDATION_FAILED`（拒绝写孤儿）；A `setFragments` 对移除 id 丢弃状态、不残留。适配层应只上报当前 scene 存在的 id，避免触发 C 校验失败。

## 5. 稳定唯一 ID 的传递

- C 热点 id = FNV-1a(`name`) → `hs-xxxxxxxx`；**改名→id 变**→旧探索记录指向不存在的 id（`visitHotspot` 会拒绝）。scene.id 重生成保持不变（in-place update）。
- A `fragment.id` 由调用方提供；`setFragments` 依 id 保留 viewed、去重首条保留。
- **对接约定（方向，待验证）**：适配层必须**直接采用 C `hotspot.id` 作为 A `fragment.id`**，不得自造或重新哈希，否则探索进度与 A 状态错位。
- 需 B/C 确认：热点命名是否保持稳定，或是否改用 UUID（C AGENTS 要求 UUID，但现热点为内容哈希，属 C 现状，**不由 A 修改**）。

## 6. 来源标识（provenance）不丢失

- C 四类 `sourceType`：`user_confirmed / image_observed / ai_inferred / fictional`（`constants.SOURCE_TYPES`，中文标签 `SOURCE_TYPE_LABELS`：用户确认/图片可见/AI 推测/想象内容）。
- `hotspot` 必带 `sourceType` + `sourceIds[]`；analysis 的 `sourcedValue` 另带 `confidence`(0–1)、`confirmed`；`assertConfirmedProvenance` 规定**仅 user_confirmed 可 confirmed=true**。
- mock `buildScene` 热点恒 `ai_inferred` + 固定 description 注记（"位置为示意排布，非照片观察"）；场景背景为绘制模板、**不用用户照片**。
- **A 目前无 provenance 字段与展示**。适配方向：适配层把 `sourceType/sourceIds/confidence/confirmed` 放入 `fragment.raw` 透传，并在 A 详情面板/徽标增加来源标签（**待验证**，A 侧增强）；不得把 `ai_inferred/fictional` 呈现为用户确认事实；保留 C 的"示意排布非真实位置"注记。
- 需确认：来源标签 UI 由 A 渲染还是 C 包装渲染；文案是否复用 `SOURCE_TYPE_LABELS`（**待 B/C 确认**）。

## 7. 接入点与避免绕过 C 流程

- C 页面 `src/app/memory/[id]/page.js` 组合 `MemoryAssetsViewer + MemoryAnalysisPanel + MemoryScenePanel`（各取 `memoryId` 自加载）。
- `MemoryScenePanel` **自持状态** `{memory, scene, visitedHotspots}`，调 `readScene / generateScene / visitHotspot`；生成门禁 `memory.status ∈ [ready, completed]`（先确认整理结果）。
- `SceneCanvas` 为**纯展示组件**，props = `{ scene, visitedHotspots, onHotspotClick }`。
- **推荐接入（方向，待验证）**：A 新增一个 React 适配组件，接受与 `SceneCanvas` **相同的 props 契约**，内部 mount `MemorySpace`、映射 `hotspots→fragments`、`visited→viewed`、`onFragmentOpen→onHotspotClick`；由 **C 决定**在 `MemoryScenePanel` 内替换或并列 `SceneCanvas`（该替换属 C 侧改动，需 C 配合）。
- A 适配层**不直接调 C services、不直接写 IndexedDB**，避免绕过 C 的状态、门禁与持久化；不重复实现 C 的加载/生成/探索记录。

## 8. 框架兼容风险（Next/React vs A 原生，待验证）

- A 脚本顶层引用 `window/document/matchMedia` → **SSR 会报错**；需 `"use client"` + `useEffect` 挂载或 `next/dynamic ssr:false`。
- A 为全局命名空间、非 ESM；C 为 ESM/JSX + `@/` 别名；A 文件需以 import 副作用或 dynamic 方式引入。
- Tailwind **preflight** 重置 button/边框/背景，可能与 A CSS 冲突；A 全局类名 `.ms/.mf` 与 C 无命名冲突，但 CSS 加载顺序/层级需确认。
- A 自带详情面板与焦点管理（命令式 DOM）vs React 重渲染：适配层应**单向** props→A、A 事件→回调，避免双写 DOM。
- C 背景当前为绘制模板；若未来 `background.type=asset` 引用用户图，A 是否支持及隐私边界需 B/C 确认。

## 9. 必须由 B、C 确认或配合的问题

1. 接入形态与替换归属：A 适配组件替换还是并列 `SceneCanvas`，由 C 决定并实施 C 侧改动。
2. 探索触发时机对齐（A open vs C click）与是否经 `onHotspotClick→visitHotspot` 上报。
3. 坐标契约（以 C 0–1 为准）、A 夹取放宽、逐碎片深度、**24 热点防重叠布局**的 A 侧增强批准。
4. 热点 id 稳定性（内容哈希 vs UUID）与"改名导致探索孤儿"的产品决策。
5. provenance 展示归属（A 渲染 vs C 包装）、标签文案、`confidence/confirmed` 透传。
6. SSR/client-only 挂载方式与 Tailwind 共存方案批准。
7. `background=asset`（用户图）是否进入 A 场景及隐私边界。
8. 真实 AI（B）输出与 C `sceneSchema` 的对齐（本次仅见 mock provider）。

## 10. 已通过代码阅读确认的内容

- C 技术栈与架构规则（`package.json`、`AGENTS.md`）。
- C hotspot/scene/exploration/sourcedValue 字段与约束（各 schema、`constants.js`）。
- C 坐标归一化 0–1、深度带、`hotspotLayout` 输出 left/top 百分比 + scale/zIndex/opacity（`sceneTemplates.js`）。
- C 热点 id 为内容哈希、scene 重生成 in-place 保 id（`sceneTemplates.js`、`aiService.generateScene`）。
- C 探索=点击时事务持久化、per memoryId、去重、重生成不丢（`explorationRepository.js`、`sceneService.visitHotspot`）。
- C 场景面板自持状态 + 生成门禁；`SceneCanvas` 纯展示 props 契约（`MemoryScenePanel.jsx`、`SceneCanvas.jsx`、`memory/[id]/page.js`）。
- C 四类 sourceType 与 confirmed 约束、mock 热点恒 ai_inferred + 示意注记（`sourceSchema.js`、`constants.js`、`mockProvider.js`）。
- A 字段/三态/回调/`setFragments` 保留与去重/坐标夹取/8 槽位（A `src/*`、`README.md`）。

## 11. 尚未运行 / 测试 / 联调的内容

- 本文**所有适配方向**（props 契约适配组件、坐标转换、深度映射、24 热点布局、provenance UI、探索映射）均**待验证**，未实现、未运行。
- 未运行 C 项目、未安装 C 依赖、未跑 C vitest；未做 A↔C 任何运行联调。
- SSR 挂载、Tailwind 共存、React 与 A 命令式 DOM 共存均未实测。
- 坐标夹取边界、>8 碎片重叠为**代码阅读推断**，未在 A↔C 真实数据下实测。

## 12. 归属与禁止事项重申

- C 代码仅读、不改、不覆盖、不删除；不复制进 A 交付、不生成含 C 副本的交付包。
- 不修改 B/C 代码；差异优先在 A 组件/适配层内处理。
- 仅改 A 无法完成对接时，记录问题/影响/需 C 配合事项（见 §9），不自行改 C。
- 未与 B/C 确认的接口/规则不写成已确定事实；未运行/联调一律标"待验证"。