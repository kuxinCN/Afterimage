/* 余像 Afterimage · 对接演示接线（不属于组件）。模拟数据 / 未接入真实 AI / 未与 C 组联调。 */
(function () {
  'use strict';

  var scenes = window.AFTERIMAGE_MOCK_SCENES;
  var stage = document.getElementById('stage');
  var eventLog = document.getElementById('eventLog');
  var issueLog = document.getElementById('issueLog');
  var visitedChips = document.getElementById('visitedChips');
  var sceneSelect = document.getElementById('sceneSelect');
  var failToggle = document.getElementById('failToggle');

  // 外部「持久化」模拟：仅浏览器内存，代表 C 组 IndexedDB 的角色
  var externalStore = new Set(scenes.initialVisited);

  function log(text, cls) {
    var li = document.createElement('li');
    li.className = cls || '';
    li.textContent = text;
    eventLog.insertBefore(li, eventLog.firstChild);
  }

  function renderVisited() {
    visitedChips.textContent = '';
    if (externalStore.size === 0) {
      var empty = document.createElement('span');
      empty.className = 'chip';
      empty.textContent = '（无）';
      visitedChips.appendChild(empty);
      return;
    }
    externalStore.forEach(function (id) {
      var c = document.createElement('span');
      c.className = 'chip';
      c.textContent = id;
      visitedChips.appendChild(c);
    });
  }

  function reportIssues(issues) {
    issues.forEach(function (iss) {
      var li = document.createElement('li');
      li.className = 'prog';
      li.textContent = '[' + iss.code + '] ' + iss.message + (iss.hotspotId ? ' (' + iss.hotspotId + ')' : '');
      issueLog.insertBefore(li, issueLog.firstChild);
    });
  }

  var handle = window.Afterimage.mountScene(stage, {
    scene: scenes.calm,
    visitedHotspots: Array.from(externalStore),
    exploreOn: 'open',
    onHotspotClick: function (id) {
      log('用户点击碎片 → onHotspotClick(' + id + ')', 'user');
      if (failToggle.checked) {
        log('外部记录失败：不标记已探索（A 不做乐观标记）', 'fail');
        return;
      }
      externalStore.add(id);
      handle.setVisited(Array.from(externalStore));
      log('外部已持久化 ' + id + ' → setVisited 回灌，界面显示已探索', 'ext');
      renderVisited();
    },
    onIssues: reportIssues
  });

  function loadScene(key) {
    handle.update({ scene: scenes[key], visitedHotspots: Array.from(externalStore) });
    log('程序数据更新 update()：scene=' + key + '（不触发用户点击）', 'prog');
  }

  sceneSelect.addEventListener('change', function () { loadScene(sceneSelect.value); });
  document.getElementById('reloadBtn').addEventListener('click', function () { loadScene(sceneSelect.value); });
  document.getElementById('resetVisitedBtn').addEventListener('click', function () {
    externalStore.clear();
    handle.setVisited([]);
    log('外部探索已重置（程序 setVisited，不触发用户点击）', 'ext');
    renderVisited();
  });

  renderVisited();
  log('对接演示就绪：外部 scene=calm，初始已探索 ' + Array.from(externalStore).join(', '), 'prog');
})();