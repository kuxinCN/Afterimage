/* 余像 Afterimage · 零依赖浏览器自检（A 组交付检查文件）
 * 在浏览器打开 checks/self-check.html 即自动运行；结果渲染到页面并 console.table。
 * 不依赖任何测试框架；不读库、不联网。模拟数据 / 未接入真实 AI / 未与 C 组联调。
 */
(function () {
  'use strict';

  function run() {
    var A = window.Afterimage, S = window.AFTERIMAGE_MOCK_SCENES, ad = A.SceneAdapter;
    var results = [];
    function check(name, pass, detail) { results.push({ name: name, pass: !!pass, detail: detail == null ? '' : String(detail) }); }
    function scratch() { var d = document.createElement('div'); d.style.cssText = 'position:fixed;left:-9999px;top:0;width:600px;height:400px;'; document.body.appendChild(d); return d; }

    // 1 适配：字段 / 坐标 / 来源 / 探索
    var calm = ad.adaptScene(S.calm, { visitedHotspots: S.initialVisited });
    check('adapt: calm 5 碎片且 id 沿用', calm.fragments.length === 5 && calm.fragments[0].id === 'hs-a1b2c3d4');
    check('adapt: name→title / description→content', calm.fragments[0].title === '搪瓷杯' && calm.fragments[0].content.indexOf('虚构示例') >= 0);
    check('adapt: 0~1→百分比', calm.fragments.every(function (f) { return f.position && Math.abs(f.position.x - f.raw.position.x * 100) < 1e-9 && Math.abs(f.position.y - f.raw.position.y * 100) < 1e-9; }));
    check('adapt: sourceType/sourceIds 保留', calm.fragments.every(function (f) { return f.sourceType === f.raw.sourceType && Array.isArray(f.sourceIds); }));
    check('adapt: confirmed 仅 user_confirmed', calm.fragments.every(function (f) { return f.confirmed === (f.sourceType === 'user_confirmed'); }));
    check('adapt: 外部 visited→exploredIds', calm.exploredIds.join(',') === 'hs-a1b2c3d4');

    // 2 边界降级
    var edge = ad.adaptScene(S.edge, {});
    var codes = {};
    edge.issues.forEach(function (i) { codes[i.code] = true; });
    check('edge: 重复 id 保留首条', edge.fragments.filter(function (f) { return f.id === 'hs-ok00001'; }).length === 1 && codes.DUPLICATE_ID);
    check('edge: 缺 id 跳过', !edge.fragments.some(function (f) { return f.title === '缺少 id 应被跳过'; }) && codes.MISSING_ID);
    check('edge: 异常坐标夹取', (edge.fragments.find(function (f) { return f.id === 'hs-badpos1'; }) || {}).position && codes.POSITION_CLAMPED);
    check('edge: 缺坐标置 null', (edge.fragments.find(function (f) { return f.id === 'hs-nopos1'; }) || {}).position === null && codes.POSITION_MISSING);
    check('edge: 超长名称截断 120', (edge.fragments.find(function (f) { return f.id === 'hs-longname'; }) || {}).title.length === 120 && codes.NAME_TRUNCATED);
    check('edge: 非字符串描述→空', codes.INVALID_DESCRIPTION);
    check('edge: 误标 confirmed 降级', (edge.fragments.find(function (f) { return f.id === 'hs-fakeconf'; }) || {}).confirmed === false && codes.CONFIRMED_DOWNGRADED);
    check('edge: 未知 type 用通用图形', (edge.fragments.find(function (f) { return f.id === 'hs-unktype'; }) || {}).kind === 'keepsake');
    check('empty: 空场景 0 碎片', ad.adaptScene(S.empty, {}).fragments.length === 0);
    check('null scene: SCENE_INVALID', ad.adaptScene(null, {}).issues[0].code === 'SCENE_INVALID');
    check('pickExploredIds: 孤儿丢弃', ad.pickExploredIds(['hs-a1b2c3d4', 'hs-nope'], calm.fragments).join(',') === 'hs-a1b2c3d4');

    // 3 挂载 / 回调 / 探索 / 卸载
    var box = scratch(), clicks = [];
    var h = A.mountScene(box, { scene: S.calm, visitedHotspots: ['hs-a1b2c3d4'], exploreOn: 'open', onHotspotClick: function (id) { clicks.push(id); } });
    function q(id) { return box.querySelector('[data-fragment-id="' + id + '"]'); }
    check('mount: 外部 explored 回灌徽标', q('hs-a1b2c3d4').querySelector('.mf-explored').hidden === false && q('hs-e5f6a7b8').querySelector('.mf-explored').hidden === true);
    q('hs-e5f6a7b8').click();
    check('mount: 用户点击触发 onHotspotClick', clicks.length === 1 && clicks[0] === 'hs-e5f6a7b8');
    check('mount: 不做乐观已探索标记', h.getState().exploredIds.join(',') === 'hs-a1b2c3d4');
    h.space.openFragment('hs-c9d0e1f2'); h.space.closePanel();
    check('mount: 程序 open/close 不伪装点击', clicks.length === 1);
    h.update({ scene: S.revisit, visitedHotspots: ['hs-a1b2c3d4'] });
    check('mount: update 不伪装点击且保留 explored', clicks.length === 1 && !!q('hs-new11223') && q('hs-a1b2c3d4').querySelector('.mf-explored').hidden === false);
    h.setVisited(['hs-e5f6a7b8']);
    check('mount: setVisited 回灌且不伪装点击', q('hs-e5f6a7b8').querySelector('.mf-explored').hidden === false && clicks.length === 1);
    h.destroy();
    check('mount: 卸载清理节点', box.childElementCount === 0);
    box.remove();

    // 4 文本安全
    var box2 = scratch();
    var h2 = A.mountScene(box2, { scene: S.edge, visitedHotspots: [] });
    h2.space.openFragment('hs-xss001');
    var panel = box2.querySelector('.ms-panel');
    check('xss: 标题按文本呈现', box2.querySelector('.ms-panel-title').textContent === '<img src=x onerror=alert(1)>');
    check('xss: 正文 script 按文本呈现', box2.querySelector('.ms-panel-body').textContent.indexOf('<script>alert(2)</script>') >= 0);
    check('xss: 未注入 img/script 节点', panel.querySelector('img') === null && panel.querySelector('script') === null);
    h2.destroy(); box2.remove();

    // 5 核心状态回归
    var box3 = scratch(), closes = [];
    var sp = new A.MemorySpace(box3, { fragments: [{ id: 'a', title: 'A' }, { id: 'b', title: 'B' }], onFragmentClose: function (d, i) { closes.push(i); } });
    box3.querySelector('[data-fragment-id="a"]').click(); sp.closePanel();
    check('core: 关闭标记 viewed', sp.getState().fragments.find(function (f) { return f.id === 'a'; }).status === 'viewed');
    sp.setFragments([{ id: 'a', title: 'A' }, { id: 'b', title: 'B' }]);
    check('core: 同 id viewed 保留', sp.getState().fragments.find(function (f) { return f.id === 'a'; }).status === 'viewed');
    sp.setFragments([{ id: 'b', title: 'B' }]); sp.setFragments([{ id: 'a', title: 'A' }, { id: 'b', title: 'B' }]);
    check('core: 移除 id 重现为 unseen', sp.getState().fragments.find(function (f) { return f.id === 'a'; }).status === 'unseen');
    var dup = sp.setFragments([{ id: 'a', title: 'A' }, { id: 'a', title: 'A2' }]);
    check('core: 重复 id 报告', dup.droppedDuplicateIds.join(',') === 'a');
    sp.setFragments([{ id: 'a', title: 'A' }, { id: 'b', title: 'B' }]);
    sp.openFragment('b');
    var rem = sp.setFragments([{ id: 'a', title: 'A' }]);
    check('core: 打开项被移除回调+报告', rem.closedOpenId === 'b' && rem.removedOpenId === 'b' && closes.some(function (c) { return c.id === 'b' && c.removed === true; }));
    sp.destroy(); box3.remove();

    // 6 外部探索更新 / scene 更新不打断正在阅读的详情
    var box4 = scratch(), clicks4 = [], closes4 = [];
    var h4 = A.mountScene(box4, {
      scene: S.calm, visitedHotspots: [], exploreOn: 'open',
      onHotspotClick: function (id) { clicks4.push(id); },
      onFragmentClose: function (d, i) { closes4.push(i); }
    });
    function q4(id) { return box4.querySelector('[data-fragment-id="' + id + '"]'); }
    var panel4 = box4.querySelector('.ms-panel');
    q4('hs-e5f6a7b8').click();
    var openBefore = h4.getState().openId;
    var rep4a = h4.update({ scene: S.calm, visitedHotspots: ['hs-e5f6a7b8'] });
    check('explore-update: 仅 visited 更新详情保持打开', panel4.hidden === false && h4.getState().openId === openBefore && rep4a.sceneChanged === false);
    check('explore-update: 外部探索徽标正确', q4('hs-e5f6a7b8').querySelector('.mf-explored').hidden === false);
    check('explore-update: 不重复用户点击/不触发关闭', clicks4.length === 1 && closes4.length === 0);
    check('explore-update: 焦点仍在面板内', panel4.contains(document.activeElement));
    var clone = JSON.parse(JSON.stringify(S.calm));
    h4.update({ scene: clone, visitedHotspots: ['hs-e5f6a7b8'] });
    check('explore-update: 同内容新对象不打断详情', panel4.hidden === false && h4.getState().openId === openBefore && closes4.length === 0 && clicks4.length === 1);
    var rep4c = h4.update({ scene: S.revisit, visitedHotspots: ['hs-e5f6a7b8'] });
    check('scene-change: 打开项仍存在则保持阅读', panel4.hidden === false && h4.getState().openId === openBefore && rep4c.preservedOpenId === openBefore && closes4.length === 0);
    var rep4d = h4.update({ scene: S.edge, visitedHotspots: [] });
    check('scene-change: 打开项被移除安全关闭+报告', panel4.hidden === true && rep4d.removedOpenId === 'hs-e5f6a7b8' && closes4.some(function (c) { return c.id === 'hs-e5f6a7b8' && c.removed === true; }));
    h4.destroy(); box4.remove();

    return results;
  }

  function render(results) {
    var pass = results.filter(function (r) { return r.pass; }).length;
    var host = document.getElementById('results');
    if (host) {
      host.textContent = '';
      var head = document.createElement('p');
      head.textContent = '自检结果：' + pass + ' / ' + results.length + ' 通过（模拟数据 / 未接入真实 AI / 未与 C 组联调）';
      host.appendChild(head);
      var table = document.createElement('table');
      results.forEach(function (r) {
        var tr = document.createElement('tr');
        var td1 = document.createElement('td'); td1.textContent = r.pass ? '通过' : '失败'; td1.style.color = r.pass ? '#5ee6a8' : '#ff9d9d';
        var td2 = document.createElement('td'); td2.textContent = r.name;
        tr.appendChild(td1); tr.appendChild(td2); table.appendChild(tr);
      });
      host.appendChild(table);
    }
    if (window.console && console.table) console.table(results);
    window.AFTERIMAGE_SELF_CHECK = results;
    return results;
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { render(run()); });
  } else {
    render(run());
  }
})();